<?php
// created: 2016-10-24 00:40:32
$dictionary["sng_CallHistory"]["fields"]["sng_callhistory_calls"] = array (
  'name' => 'sng_callhistory_calls',
  'type' => 'link',
  'relationship' => 'sng_callhistory_calls',
  'source' => 'non-db',
  'module' => 'Calls',
  'bean_name' => 'Call',
  'vname' => 'LBL_SNG_CALLHISTORY_CALLS_FROM_CALLS_TITLE',
);
