<?php
// created: 2016-10-24 00:40:32
$dictionary["Lead"]["fields"]["sng_callhistory_leads"] = array (
  'name' => 'sng_callhistory_leads',
  'type' => 'link',
  'relationship' => 'sng_callhistory_leads',
  'source' => 'non-db',
  'module' => 'sng_CallHistory',
  'bean_name' => 'sng_CallHistory',
  'vname' => 'LBL_SNG_CALLHISTORY_LEADS_FROM_SNG_CALLHISTORY_TITLE',
);
