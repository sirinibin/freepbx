<?php
// created: 2016-10-24 00:40:32
$dictionary["Contact"]["fields"]["sng_callhistory_contacts"] = array (
  'name' => 'sng_callhistory_contacts',
  'type' => 'link',
  'relationship' => 'sng_callhistory_contacts',
  'source' => 'non-db',
  'module' => 'sng_CallHistory',
  'bean_name' => 'sng_CallHistory',
  'vname' => 'LBL_SNG_CALLHISTORY_CONTACTS_FROM_SNG_CALLHISTORY_TITLE',
);
